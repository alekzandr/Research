#include <Windows.h>

DWORD WINAPI ThreadProc(LPVOID lpParameter) {
    // Load the DLL
    HMODULE hModule = LoadLibraryA("calc.dll");
    if (hModule != NULL) {
        // Get the address of the exported function
        FARPROC functionAddr = GetProcAddress(hModule, "DllMain");
        if (functionAddr != NULL) {
            // Call the exported function
            typedef void (*MyFunction)();
            MyFunction myFunction = (MyFunction)functionAddr;
            myFunction();
        }

        // Free the DLL
        FreeLibrary(hModule);
    }

    return 0;
}

int main() {
    // Create a thread to load the DLL
    HANDLE hThread = CreateThread(NULL, 0, ThreadProc, NULL, 0, NULL);
    if (hThread != NULL) {
        // Wait for the thread to finish
        WaitForSingleObject(hThread, INFINITE);

        // Close the thread handle
        CloseHandle(hThread);
    }

    return 0;
}
