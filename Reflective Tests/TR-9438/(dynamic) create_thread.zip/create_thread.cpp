#include <Windows.h>
#include <fstream>

DWORD WINAPI ThreadProc(LPVOID lpParameter) {
    // Open the DLL file in binary mode, and move the file pointer to the end
    std::ifstream file("calc.dll", std::ios::binary | std::ios::ate);
    if (!file) {
        // If the file couldn't be opened, exit the thread with an error code
        return 1;
    }

    // Get the size of the file by checking the position of the file pointer (which is at the end of the file)
    std::streamsize size = file.tellg();
    // Move the file pointer back to the start of the file
    file.seekg(0, std::ios::beg);

    // Allocate a buffer to hold the file data
    char* buffer = new char[size];
    // Read the file data into the buffer
    if (!file.read(buffer, size)) {
        // If the file couldn't be read, free the buffer and exit the thread with an error code
        delete[] buffer;
        return 1;
    }

    // Allocate memory to hold the DLL code. This memory is marked as executable, which is necessary to run code from it.
    void* execMem = VirtualAlloc(NULL, size, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (!execMem) {
        // If the memory couldn't be allocated, free the buffer and exit the thread with an error code
        delete[] buffer;
        return 1;
    }

    // Copy the DLL file data into the allocated memory
    CopyMemory(execMem, buffer, size);

    // The buffer isn't needed anymore, so it can be freed
    delete[] buffer;

    // Calculate the address of the DllMain function within the loaded DLL.
    // This is done by subtracting the base address of the DLL from the address of the DllMain function, then adding that offset to the base address of the new memory region.
    FARPROC functionAddr = (FARPROC)((char*)execMem + ((DWORD_PTR)GetProcAddress(LoadLibraryA("calc.dll"), "DllMain") - (DWORD_PTR)LoadLibraryA("calc.dll")));
    if (functionAddr != NULL) {
        // Cast the function address to the correct type (a function taking a HINSTANCE, a DWORD, and a LPVOID, and returning a BOOL), and call it.
        typedef BOOL(*DllMainFunc)(HINSTANCE, DWORD, LPVOID);
        DllMainFunc dllMain = (DllMainFunc)functionAddr;
        dllMain((HINSTANCE)execMem, DLL_PROCESS_ATTACH, NULL);
    }

    return 0;
}

int main() {
    // Create a new thread that will load the DLL
    HANDLE hThread = CreateThread(NULL, 0, ThreadProc, NULL, 0, NULL);
    if (hThread != NULL) {
        // If the thread was created successfully, wait for it to finish
        WaitForSingleObject(hThread, INFINITE);

        // After the thread has finished, close the handle to it
        CloseHandle(hThread);
    }

    return 0;
}
